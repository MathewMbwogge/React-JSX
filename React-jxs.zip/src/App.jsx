import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css';
import Button from 'react-bootstrap/Button';

// importing components
import User from "./components/User";
// importing profiles
import profilePicUser from "./Profiles/mypic.png";

function App() {
  return (
    <>
    <fieldset>
      <legend>My Vite+React App</legend>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
    </fieldset>
      <div class="details">
        <User
        profile_picture={
          <img src={profilePicUser} />
        }
        name="Mark" 
        surname="Johnson" 
        date_of_birth="10-12-1985"
        address="225 Hill Crest, Montreal" 
        country="Canada"
        company="Space Digital" 
        role="Digital Engineer"
        email="mark.joe@spacegit.ca" 
        phone="1-800-622-6232"
        shopping_cart="[Cheese, Burger, Lamb, Cereals, Eggs, Whisky]"
        />
      </div>
      <hr />
      <fieldset class="footer">
      <legend></legend>
      <p>Copyright ©Mathew Mbwogge 2025 All rights reserved</p>
      <p>HyperionDev Cloud Web Developer Bootcamp</p>
      </fieldset>
    </>
  );
}

export default App;
