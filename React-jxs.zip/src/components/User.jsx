import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

// Creating a User component to be exported to App.jsx

function User({name, 
    surname, 
    date_of_birth, 
    address, country, 
    company, 
    role, 
    email, 
    phone, 
    profile_picture, 
    shopping_cart}) {
    return (
        // creating an instance of the container to automate the layout.
        <Container>
        <hr />
    
        <div>
            <h1 style={{backgroundColor: "cyan"}}>Welcome back, {name}</h1>
            <hr />
            <Row>
                <Col className="red-border">First Name: {name}</Col>
                <Col className="red-border">Surname: {surname}</Col>
            </Row>
            <p>{profile_picture}</p>
            <Row>
                <Col className="red-border">DoB: {date_of_birth}</Col>
            </Row>
            <hr />
            <h2>Current Address:</h2>
            <Row>
                <Col className="red-border">Living at {address}</Col>
            </Row>
            <Row>
                <Col className="red-border">{country}</Col>
            </Row>
            <hr />
            <h2>Professional Life</h2>
            <Row>
                <Col className="red-border">Company: {company}</Col>
                <Col className="red-border">Position: {role}</Col>
            </Row>
            <hr />
            <h2>Contact Details</h2>
            <Row>
                <Col xs={6} className="red-border">Email: {email}</Col>
                <Col className="red-border">Mobile: {phone}</Col>
            </Row>
            <hr />
            <h2>Expenses</h2>
            <Row>
                <Col className="red-border">Shopping list: {shopping_cart}</Col>
            </Row>
        </div>
        </Container>
    );
}

export default User;